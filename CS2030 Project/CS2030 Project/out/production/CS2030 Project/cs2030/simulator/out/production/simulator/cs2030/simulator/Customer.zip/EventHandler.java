package cs2030.simulator;

import java.util.ArrayList;
import java.util.List;

public class EventHandler {
    private final Event event;
    private final List<Server> serverList;
    private final List<Customer> customerList;

    public EventHandler(Event event, List<Server> serverList, List<Customer> customerList) {
        this.event = event;
        this.serverList = serverList;
        this.customerList = customerList;
    }

    public List<Event> handleEvent(){
        List<Event> nextEvent = new ArrayList<>();
        if(event.getEventState() == EventState.ARRIVAL){
            nextEvent.add(handleArrivalEvent());
        }
        else if(event.getEventState() == EventState.WAIT) {
            nextEvent.add(handleWaitEvent());
            nextEvent.add(new Event(event.getCustomer(), event.getServer().getNextAvailableTime(), event.getServer(), EventState.SERVE));
        }
        else if(event.getEventState() == EventState.SERVE) {
            event.getServer().setQueued(false);
            nextEvent.add(new Event(event.getCustomer(), event.getCustomer().getServiceCompletionTime(), event.getServer(), EventState.DONE));
        }
        else if(event.getEventState() == EventState.DONE) {
            nextEvent.add(handleDoneEvent(event));
        }
        return nextEvent;
    }

    Event handleDoneEvent(Event event) {
        Event nextEvent = null;
        return nextEvent;
    }

    Event handleArrivalEvent() {
        Event nextEvent = null;
        for (int i = 0; i < serverList.size(); i++) {
            Server s = getFreeServer();

            //THERE IS AVAILABLE SERVER
            if(s!= null){
                Customer c = new Customer(event.getCustomer().getId(), event.getCustomer().getTime(), event.getCustomer().getServiceTime(), s);
                Server s1 = new Server(s.getId(), this.event.getCustomer(), ServerState.SERVING);
//                Server s = new Server(serverList.get(i).getId(), this.event.getCustomer(), ServerState.SERVING);
                if(s.getId() != 0){
                    serverList.set(s.getId() - 1, s1);
                } else if (s.getId() == 0){
                    serverList.set(s.getId(), s1);
                }
                customerList.set(i, c);
//                nextEvent = new ServeEvent(c, serverList.get(i).serve(event.getCustomer()), event.getCustomer().getTime());
                nextEvent = new Event(c, c.getTime(), s, EventState.SERVE);
                break;
            } else {
                if (getEarliestServer().getQueued() == true) {
                    /*
                    if the server is serving one customer with a second customer waiting in the queue, and a third customer arrives,
                    then this latter customer leaves (LEAVE event).
                    In other words, there is at most one customer waiting in the queue.
                    */
                    nextEvent = (new Event(event.getCustomer(), event.getCustomer().getTime(), event.getServer(), EventState.LEAVE));
                } else {
                    nextEvent = new Event(event.getCustomer(), event.getTime(), getEarliestServer(), EventState.WAIT);
                    getEarliestServer().setQueued(true);
                }
                break;
            }
        }
        return nextEvent;
    }

    Event handleWaitEvent() {
        Event nextEvent = null;
        if(getFreeServer() != null) {
            Customer c = new Customer(event.getCustomer().getId(), event.getCustomer().getTime(), event.getCustomer().getServiceTime(), getFreeServer());
            nextEvent = new Event(c, c.getTime(), getFreeServer(), EventState.SERVE);
        }
        return nextEvent;
    }

    Server getEarliestServer() {
        serverList.sort((x, y) -> Double.compare(x.getNextAvailableTime(), x.getNextAvailableTime()));
        return serverList.get(0);
    }

    Server getFreeServer() {
        for (Server s : serverList) {
            if(s.canServe()) return s;
        }
        return null;
    }
}
