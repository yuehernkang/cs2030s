package cs2030.simulator;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

public class Simulator {
    private final int numOfServers;
    private final List<Double> arrivalTimes;
    private final static double SERVICE_TIME = 1.0;

    public Simulator(int numOfServers, List<Double> arrivalTimes) {
        this.numOfServers = numOfServers;
        this.arrivalTimes = arrivalTimes;
    }



    public void simulate() {
        PriorityQueue<Event> eventQueue = new PriorityQueue<>(new EventComparator());
        List<Server> serverList = new ArrayList<>();
        List<Customer> customersList = new ArrayList<>();

        serverList = initServer();

        for (int i = 0; i < arrivalTimes.size(); i++) {
            Customer c = new Customer((i + 1), arrivalTimes.get(i), SERVICE_TIME, null);
            customersList.add(c);
//            ArrivalEvent av = new ArrivalEvent(c, serverList, null);
            Event av = new Event(c, c.getTime(), null, EventState.ARRIVAL);
            if (i != 0) {
                av = new Event(c, c.getTime(), null, EventState.ARRIVAL);
            }
            eventQueue.add(av);
        }

        while (!eventQueue.isEmpty()) {
            Event event = eventQueue.poll();
            System.out.println(event);
            //            Event newEvent = event.getNextEvent();
            EventHandler eventHandler = new EventHandler(event, serverList, customersList);
            List<Event> latestEvent = eventHandler.handleEvent();
            for (Event e : latestEvent) {
                if (e != null) {
                    eventQueue.add(e);
                }
            }
        }

    }

    private List<Server> initServer() {
        List<Server> serverList = new ArrayList<>();
        //INITIALIZE SERVER LIST
        for (int i = 0; i < this.numOfServers; i++) {
            serverList.add(new Server(i + 1));
        }
        return serverList;
    }
}
