package cs2030.simulator;

public enum ServerState {
    IDLE,
    SERVING
}
