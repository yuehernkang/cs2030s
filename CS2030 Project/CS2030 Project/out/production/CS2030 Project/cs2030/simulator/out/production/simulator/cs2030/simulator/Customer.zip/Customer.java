package cs2030.simulator;

public class Customer{
    private final int id;
    private final double time;
    private final double serviceTime;
    private final Server server;


    public Customer() {
        this.id = 0;
        this.time = 0;
        this.serviceTime = 0;
        this.server = null;
    }

    public Customer(int id, double time, double serviceTime, Server server){
        this.id = id;
        this.time = time;
        this.serviceTime = serviceTime;
        this.server = server;
    }

    public Server getServer() {
        return this.server;
    }

    public double getServiceTime() {
        return serviceTime;
    }

    public double getTime() {
        return this.time;
    }

    public int getId() {
        return this.id;
    }
    public double getServiceCompletionTime() {
        return this.time + this.serviceTime;
    }

    @Override
    public String toString() {
        return this.getTime() + " ";
    }

}
