package cs2030.simulator;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numOfServers = sc.nextInt();
        sc.nextLine();

        List<Double> arrivalTimes = new ArrayList<>();

        while (sc.hasNextDouble()) {
            arrivalTimes.add(sc.nextDouble());
        }

        Simulator s = new Simulator(numOfServers, arrivalTimes);
        s.simulate();
        sc.close();

    }
}
