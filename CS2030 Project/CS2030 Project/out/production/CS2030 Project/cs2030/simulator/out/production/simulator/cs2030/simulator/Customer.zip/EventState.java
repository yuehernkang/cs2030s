package cs2030.simulator;

public enum EventState {
    ARRIVAL,
    SERVE,
    WAIT,
    DONE,
    LEAVE,
}
