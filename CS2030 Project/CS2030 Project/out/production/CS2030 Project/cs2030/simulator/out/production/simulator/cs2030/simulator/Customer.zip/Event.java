package cs2030.simulator;

/*
EVENTS:
ARRIVE, SERVE, WAIT, LEAVE and DONE

ARRIVE → SERVE → DONE
ARRIVE → WAIT → SERVE → DONE
ARRIVE → LEAVE

ARRIVE:
ARRIVAL EVENT GENERATES A SERVE EVENT
~SERVE~ IF THERE ARE AVAILABLE SERVERS,
~WAIT~ IF THERE ARE NO AVAILABLE SERVERS
~LEAVE~ ???

SERVE EVENT:
GENERATE A DONE EVENT

DONE EVENT:
GENERATE STATISTICS
*/

public class Event {
    private final Customer customer;
    private final double time;
    private final Server server;
    private final EventState eventState;

    public Event(Customer customer, double time, Server server, EventState eventState) {
        this.customer = customer;
        this.time = time;
        this.server = server;
        this.eventState = eventState;
    }

    public Server getServer () { return this.server; }

    public Customer getCustomer() {
        return this.customer;
    }

    public EventState getEventState() {return this.eventState;}

    public double getTime() {
        return this.time;
    }

    public int getCustomerId() {
        return this.customer.getId();
    }

//    abstract Event getNextEvent();

    @Override
    public String toString() {
        if(this.eventState == EventState.ARRIVAL){
            return this.time + " " + this.customer.getId() + " " + this.eventState;
        }
        else if(this.eventState == EventState.SERVE){
            return this.time + " " + this.customer.getId() + " " + this.eventState + " BY SERVER " + this.server.getId();
        }
        else if(this.eventState == EventState.WAIT){
            return this.time + " " + this.customer.getId() + " " + this.eventState + " AT SERVER " + this.server.getId();
        }
        else if(this.eventState == EventState.DONE){
            return this.time + " " + this.customer.getId() + " " + this.eventState + " SERVING BY SERVER " + this.server.getId();
        }
        else if(this.eventState == EventState.LEAVE){
            return this.time + " " + this.customer.getId() + " " + this.eventState;
        }
        return "WRONG";
    }

}
