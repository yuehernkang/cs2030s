package cs2030.simulator;

public class Server {
    private final int id;
    private final Customer customer;
    private final ServerState serverState;
    private boolean isQueued;

    //Simulator to create server
    public Server(int id){
        this.id = id;
        this.customer = new Customer();
        this.serverState = ServerState.IDLE;
        this.isQueued = false;
    }

    //Server that start serving
    public Server(int id, Customer customer, ServerState serverState){
        this.id = id;
        this.customer = customer;
        this.serverState = serverState;
        this.isQueued = false;
    }

    public int getId() {
        return this.id;
    }

    public void setQueued(boolean queued) {
        isQueued = queued;
    }

    public boolean getQueued() {
        return this.isQueued;
    }

    public double getNextAvailableTime() {
        //IF NO CUSTOMER , WILL RETURN 0
        //IF GOT CUSTOMER, WILL RETURN CUSTOMER'S TIME + 1
        return this.customer.getServiceCompletionTime();
    }

    public Server serve(Customer customer) {
        if(canServe()) {
            return new Server(this.id, customer, ServerState.SERVING);
        } else {
            return this;
        }
    }

    //Check if this server can serve the next customer
    //customer time + service time = time when done
    //if time when done is less than the next customer time
    boolean canServe() {
        if(this.serverState == ServerState.SERVING){
            return false;
        } else {
            return true;
        }
    }

}
