package cs2030.simulator;

public class StatisticsHandler {
    private static int numOfCustomers = 1;
    private static int numOfCustomersLeftWithoutService = 0;
}
