package cs2030.simulator;

public enum CustomerState {
    ARRIVE,
    SERVING,
    WAITING,
    LEAVE,
    DONE
}
